import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, 
  User, 
  Car, 
  Building2, 
  Sidebar as SidebarIcon,
  Loader2,
  Trash2,
  Globe,
  Tag,
  MapPin,
  CircleDollarSign,
  PlusCircle,
  X,
  ChevronRight,
  TrendingUp,
  Search,
  LogIn,
  LogOut,
  HelpCircle,
  ImagePlus
} from 'lucide-react';

type Asset = {
  id: string;
  type: 'car' | 'building';
  title: string;
  price: string;
  location: string;
  details: string;
  image: string;
};

const INITIAL_ASSETS: Asset[] = [];

export default function App() {
  const [activeTab, setActiveTab] = useState<'cars' | 'buildings'>('cars');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showHelpModal, setShowHelpModal] = useState(false);
  const [user, setUser] = useState<{ email: string } | null>(null);

  // Form states
  const [newAsset, setNewAsset] = useState<Partial<Asset>>({ type: 'car', image: '' });
  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewAsset(prev => ({ ...prev, image: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginForm.email && loginForm.password) {
      setUser({ email: loginForm.email });
      setIsLoggedIn(true);
      setShowLoginModal(false);
      setLoginForm({ email: '', password: '' });
    }
  };

  const handleLogout = () => {
    setUser(null);
    setIsLoggedIn(false);
  };

  const handleCreateAsset = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isLoggedIn) {
      setShowLoginModal(true);
      return;
    }
    
    if (newAsset.title && newAsset.price && newAsset.location) {
      const asset: Asset = {
        id: Math.random().toString(36).substr(2, 9),
        type: newAsset.type as 'car' | 'building',
        title: newAsset.title,
        price: newAsset.price,
        location: newAsset.location,
        details: newAsset.details || '',
        image: newAsset.image || `https://picsum.photos/seed/${newAsset.title}/800/600`
      };
      
      setAssets(prev => [asset, ...prev]);
      setShowAddModal(false);
      setNewAsset({ type: 'car', image: '' });
    }
  };

  const filteredAssets = assets.filter(a => a.type === activeTab.slice(0, -1));

  return (
    <div className="flex h-screen bg-[#0A0A0C] text-[#F3F2F0] font-sans selection:bg-amber-500/30">
      {/* Sidebar */}
      <motion.aside 
        initial={false}
        animate={{ width: sidebarOpen ? 280 : 0, opacity: sidebarOpen ? 1 : 0 }}
        className="border-r border-white/5 bg-[#0F0F12] flex flex-col overflow-hidden"
      >
        <div className="p-8 pb-4 flex items-center gap-4">
          <div className="w-10 h-10 rounded-full bg-amber-500 flex items-center justify-center shadow-lg shadow-amber-900/20">
            <TrendingUp className="w-6 h-6 text-black" />
          </div>
          <div>
            <span className="block font-bold text-xl tracking-tight leading-none uppercase">URBAN</span>
            <span className="text-[10px] uppercase tracking-[0.2em] font-medium text-amber-500/80">Պրեմիում Գույք</span>
          </div>
        </div>

        <div className="px-6 my-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
            <input 
              placeholder="Փնտրել..." 
              className="w-full bg-white/5 border border-white/10 rounded-full py-2 pl-10 pr-4 text-sm focus:outline-none focus:border-amber-500/50 transition-all"
            />
          </div>
        </div>

        <nav className="flex-1 px-4 space-y-1">
          <button 
            onClick={() => setActiveTab('cars')}
            className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all group ${
              activeTab === 'cars' ? 'bg-amber-500 text-black shadow-lg shadow-amber-900/20' : 'text-white/60 hover:bg-white/5'
            }`}
          >
            <div className="flex items-center gap-3">
              <Car className="w-5 h-5" />
              <span className="font-semibold">Մեքենաներ</span>
            </div>
            <span className={`text-[10px] font-mono ${activeTab === 'cars' ? 'text-black/60' : 'text-white/20'}`}>0{assets.filter(a => a.type === 'car').length}</span>
          </button>
          <button 
            onClick={() => setActiveTab('buildings')}
            className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all group ${
              activeTab === 'buildings' ? 'bg-amber-500 text-black shadow-lg shadow-amber-900/20' : 'text-white/60 hover:bg-white/5'
            }`}
          >
            <div className="flex items-center gap-3">
              <Building2 className="w-5 h-5" />
              <span className="font-semibold">Շինություններ</span>
            </div>
            <span className={`text-[10px] font-mono ${activeTab === 'buildings' ? 'text-black/60' : 'text-white/20'}`}>0{assets.filter(a => a.type === 'building').length}</span>
          </button>
          
          <button 
            onClick={() => setShowHelpModal(true)}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all text-white/60 hover:bg-white/5 mt-4"
          >
            <HelpCircle className="w-5 h-5 text-amber-500" />
            <span className="font-semibold">Օգնություն</span>
          </button>
        </nav>

        <div className="p-6 space-y-3">
          <button 
            onClick={() => {
              if (isLoggedIn) {
                setShowAddModal(true);
              } else {
                setShowLoginModal(true);
              }
            }}
            className="w-full bg-white text-black py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-amber-50 transition-all active:scale-95"
          >
            <PlusCircle className="w-5 h-5" />
            Ավելացնել հայտարարություն
          </button>
          
          {isLoggedIn ? (
            <div className="bg-white/5 rounded-2xl p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center">
                  <User className="w-4 h-4 text-amber-500" />
                </div>
                <span className="text-sm font-medium truncate max-w-[120px]">{user?.email}</span>
              </div>
              <button onClick={handleLogout} className="text-white/40 hover:text-red-400">
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button 
              onClick={() => setShowLoginModal(true)}
              className="w-full bg-white/5 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 border border-white/10 hover:bg-white/10 transition-all"
            >
              <LogIn className="w-5 h-5" />
              Մուտք
            </button>
          )}
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col relative overflow-hidden bg-gradient-to-br from-[#0A0A0C] via-[#0F0F12] to-[#0A0A0C]">
        {/* Header */}
        <header className="h-20 border-b border-white/5 flex items-center justify-between px-8 z-10 backdrop-blur-xl bg-[#0A0A0C]/40">
          <div className="flex items-center gap-6">
            <button 
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2.5 hover:bg-white/5 rounded-full transition-all border border-white/10"
            >
              <SidebarIcon className="w-5 h-5" />
            </button>
            <div>
               <h2 className="text-xs uppercase tracking-[0.3em] font-bold text-white/40 mb-0.5">Կատալոգ</h2>
               <h1 className="text-xl font-bold capitalize">{activeTab === 'cars' ? 'Մեքենաներ' : 'Շինություններ'}</h1>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 bg-amber-500/10 border border-amber-500/20 px-4 py-1.5 rounded-full">
              <div className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
              <span className="text-[10px] font-bold text-amber-500 uppercase tracking-widest">Շուկան ակտիվ է</span>
            </div>
            <div className="w-10 h-10 rounded-full border border-white/10 bg-white/5 flex items-center justify-center hover:bg-white/10 cursor-pointer transition-all">
              <Globe className="w-5 h-5 text-white/50" />
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-8 scroll-smooth transition-all duration-500">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 max-w-6xl mx-auto">
            <AnimatePresence mode="popLayout">
              {filteredAssets.map((asset) => (
                <motion.div
                  layout
                  key={asset.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className="group bg-[#141416] border border-white/5 rounded-[32px] overflow-hidden hover:border-amber-500/30 transition-all shadow-2xl"
                >
                  <div className="relative h-64 overflow-hidden">
                    <img 
                      src={asset.image} 
                      alt={asset.title} 
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-6 left-6 flex gap-2">
                      <span className="bg-black/60 backdrop-blur-md text-white border border-white/10 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest">
                        {asset.type === 'car' ? 'Մեքենա' : 'Գույք'}
                      </span>
                    </div>
                    <div className="absolute bottom-0 left-0 w-full p-6 bg-gradient-to-t from-black/80 to-transparent">
                      <div className="flex items-end justify-between">
                        <h3 className="text-2xl font-bold leading-tight">{asset.title}</h3>
                        <span className="text-amber-500 font-mono text-xl font-bold">{asset.price}</span>
                      </div>
                    </div>
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="flex items-center gap-6 text-[#8E9299]">
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-amber-500/60" />
                        <span className="text-sm">{asset.location}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Tag className="w-4 h-4 text-amber-500/60" />
                        <span className="text-sm truncate max-w-[150px]">{asset.details}</span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => {
                          setSelectedAsset(asset);
                          setShowDetailModal(true);
                        }}
                        className="flex-1 bg-white/5 hover:bg-amber-500 hover:text-black py-3 rounded-2xl font-bold transition-all border border-white/10 hover:border-transparent"
                      >
                        Տեսնել ավելին
                      </button>
                      <button className="w-12 h-12 flex items-center justify-center rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all">
                        <CircleDollarSign className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
          
          {filteredAssets.length === 0 && (
            <div className="flex flex-col items-center justify-center h-[60vh] text-center space-y-4">
               <div className="w-20 h-20 rounded-full bg-white/5 flex items-center justify-center">
                  <Search className="w-8 h-8 text-white/20" />
               </div>
               <h2 className="text-2xl font-bold">Հայտարարություններ չկան</h2>
               <p className="text-[#8E9299] max-w-xs">Փնտրեք այլ կատեգորիաներում:</p>
            </div>
          )}
        </div>

        {/* Floating background noise */}
        <div className="absolute inset-0 pointer-events-none opacity-[0.03] z-0" 
             style={{ backgroundImage: 'url("https://www.transparenttextures.com/patterns/carbon-fibre.png")' }} />
      </main>

      {/* Add Asset Modal */}
      <AnimatePresence>
        {showAddModal && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-6 backdrop-blur-2xl bg-black/60"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-[#141416] border border-white/10 rounded-[40px] w-full max-w-xl p-10 relative shadow-2xl"
            >
              <button 
                onClick={() => setShowAddModal(false)}
                className="absolute top-8 right-8 text-white/40 hover:text-white"
              >
                <X className="w-6 h-6" />
              </button>
              
              <h2 className="text-3xl font-bold mb-2">Տեղադրել հայտարարություն</h2>
              <p className="text-[#8E9299] mb-8">Լրացրեք տվյալները հրապարակման համար:</p>
              
              <form onSubmit={handleCreateAsset} className="space-y-6">
                <div>
                  <label className="block text-xs uppercase tracking-widest font-bold text-white/40 mb-2">Կատեգորիա</label>
                  <div className="flex gap-4">
                    <button 
                      type="button"
                      onClick={() => setNewAsset(prev => ({ ...prev, type: 'car' }))}
                      className={`flex-1 py-4 rounded-2xl border transition-all font-bold ${
                        newAsset.type === 'car' ? 'border-amber-500/50 bg-amber-500/10 text-amber-500' : 'border-white/10 bg-white/5 text-white/60'
                      }`}
                    >
                      Մեքենա
                    </button>
                    <button 
                      type="button"
                      onClick={() => setNewAsset(prev => ({ ...prev, type: 'building' }))}
                      className={`flex-1 py-4 rounded-2xl border transition-all font-bold ${
                        newAsset.type === 'building' ? 'border-amber-500/50 bg-amber-500/10 text-amber-500' : 'border-white/10 bg-white/5 text-white/60'
                      }`}
                    >
                      Գույք
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-xs uppercase tracking-widest font-bold text-white/40 mb-2">Անվանում</label>
                  <input 
                    required
                    value={newAsset.title || ''}
                    onChange={e => setNewAsset(prev => ({ ...prev, title: e.target.value }))}
                    className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 focus:outline-none focus:border-amber-500/50" 
                  />
                </div>
                
                <div>
                  <label className="block text-xs uppercase tracking-widest font-bold text-white/40 mb-2">Նկար (Կամընտիր)</label>
                  <div 
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full h-32 border-2 border-dashed border-white/10 rounded-2xl flex flex-col items-center justify-center gap-2 cursor-pointer hover:border-amber-500/50 hover:bg-white/5 transition-all"
                  >
                    {newAsset.image ? (
                      <img src={newAsset.image} className="w-full h-full object-cover rounded-2xl" alt="Preview" />
                    ) : (
                      <>
                        <ImagePlus className="w-8 h-8 text-white/20" />
                        <span className="text-xs text-white/40">Կտտացրեք՝ նկար ընտրելու համար</span>
                      </>
                    )}
                  </div>
                  <input 
                    type="file"
                    hidden
                    ref={fileInputRef}
                    accept="image/*"
                    onChange={handleImageUpload}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs uppercase tracking-widest font-bold text-white/40 mb-2">Գին</label>
                    <input 
                      required
                      value={newAsset.price || ''}
                      onChange={e => setNewAsset(prev => ({ ...prev, price: e.target.value }))}
                      className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 focus:outline-none focus:border-amber-500/50" 
                    />
                  </div>
                  <div>
                    <label className="block text-xs uppercase tracking-widest font-bold text-white/40 mb-2">Գտնվելու վայրը</label>
                    <input 
                      required
                      value={newAsset.location || ''}
                      onChange={e => setNewAsset(prev => ({ ...prev, location: e.target.value }))}
                      className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 focus:outline-none focus:border-amber-500/50" 
                    />
                  </div>
                </div>
                <button type="submit" className="w-full bg-amber-500 text-black py-5 rounded-2xl font-extrabold text-lg shadow-xl shadow-amber-900/20 active:scale-95 transition-all">
                  Հրապարակել
                </button>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Detail Modal */}
      <AnimatePresence>
        {showDetailModal && selectedAsset && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[70] flex items-center justify-center p-6 backdrop-blur-3xl bg-black/80"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-[#141416] border border-white/10 rounded-[40px] w-full max-w-2xl overflow-hidden relative shadow-2xl"
            >
              <button 
                onClick={() => setShowDetailModal(false)}
                className="absolute top-6 right-6 z-10 w-10 h-10 rounded-full bg-black/40 backdrop-blur-md border border-white/10 flex items-center justify-center text-white/40 hover:text-white transition-all shadow-lg"
              >
                <X className="w-6 h-6" />
              </button>
              
              <div className="h-80 relative">
                <img src={selectedAsset.image} className="w-full h-full object-cover" alt={selectedAsset.title} referrerPolicy="no-referrer" />
                <div className="absolute bottom-0 left-0 w-full p-8 bg-gradient-to-t from-black to-transparent">
                  <h2 className="text-4xl font-bold">{selectedAsset.title}</h2>
                </div>
              </div>
              
              <div className="p-8 space-y-6">
                <div className="grid grid-cols-3 gap-6">
                   <div className="bg-white/5 p-4 rounded-3xl border border-white/10">
                      <p className="text-[10px] uppercase tracking-widest font-bold text-white/40 mb-1">Գին</p>
                      <p className="text-xl font-bold text-amber-500">{selectedAsset.price}</p>
                   </div>
                   <div className="bg-white/5 p-4 rounded-3xl border border-white/10 col-span-2">
                      <p className="text-[10px] uppercase tracking-widest font-bold text-white/40 mb-1">Մանրամասներ</p>
                      <p className="text-sm text-white/80">{selectedAsset.details}</p>
                   </div>
                </div>
                
                <div className="flex items-center gap-4 text-[#8E9299]">
                   <MapPin className="w-5 h-5 text-amber-500" />
                   <span className="text-lg">{selectedAsset.location}</span>
                </div>
                
                <button className="w-full bg-white text-black py-4 rounded-2xl font-bold text-lg shadow-xl hover:bg-amber-50 transition-all">
                  Կապվել վաճառողի հետ
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Help Modal */}
      <AnimatePresence>
        {showHelpModal && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[80] flex items-center justify-center p-6 backdrop-blur-3xl bg-black/80"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-[#141416] border border-white/10 rounded-[40px] w-full max-w-sm p-10 relative shadow-2xl text-center"
            >
              <button 
                onClick={() => setShowHelpModal(false)}
                className="absolute top-8 right-8 text-white/40 hover:text-white"
              >
                <X className="w-6 h-6" />
              </button>
              
              <div className="w-20 h-20 rounded-3xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mx-auto mb-6">
                <HelpCircle className="w-10 h-10 text-amber-500" />
              </div>
              
              <h2 className="text-2xl font-bold mb-4">Օգնության կենտրոն</h2>
              <p className="text-[#8E9299] mb-8">Հարցերի կամ խնդիրների դեպքում կապվեք մեզ հետ.</p>
              
              <div className="bg-white/5 p-4 rounded-2xl border border-white/10 inline-block mb-4">
                 <p className="text-sm font-mono text-amber-500">progtest48@gmail.com</p>
              </div>
              
              <p className="text-[10px] text-white/20 uppercase tracking-widest leading-loose">
                Մենք կպատասխանենք ձեզ<br />հնարավորինս շուտ
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Login Modal */}
      <AnimatePresence>
        {showLoginModal && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center p-6 backdrop-blur-3xl bg-black/80"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-[#141416] border border-white/10 rounded-[40px] w-full max-w-md p-10 relative shadow-2xl text-center"
            >
              <button 
                onClick={() => setShowLoginModal(false)}
                className="absolute top-8 right-8 text-white/40 hover:text-white"
              >
                <X className="w-6 h-6" />
              </button>
              
              <div className="w-16 h-16 rounded-3xl bg-amber-500 flex items-center justify-center mx-auto mb-6 shadow-xl shadow-amber-900/20">
                <LogIn className="w-8 h-8 text-black" />
              </div>
              
              <h2 className="text-3xl font-bold mb-2">Բարի գալուստ</h2>
              <p className="text-[#8E9299] mb-8">Մուտք գործեք՝ հայտարարություններ ավելացնելու համար:</p>
              
              <form onSubmit={handleLogin} className="space-y-4">
                <input 
                  type="email"
                  required
                  placeholder="Էլ. հասցե"
                  value={loginForm.email}
                  onChange={e => setLoginForm(prev => ({ ...prev, email: e.target.value }))}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 focus:outline-none focus:border-amber-500/50"
                />
                <input 
                  type="password"
                  required
                  placeholder="Գաղտնաբառ"
                  value={loginForm.password}
                  onChange={e => setLoginForm(prev => ({ ...prev, password: e.target.value }))}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 focus:outline-none focus:border-amber-500/50"
                />
                <button type="submit" className="w-full bg-amber-500 text-black py-4 rounded-2xl font-bold text-lg hover:bg-amber-400 transition-all active:scale-95">
                  Մուտք գործել
                </button>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
